package com.example.persistencia.view;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.persistencia.R;
import com.example.persistencia.database.ProdutoDAO;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    public static final String SHARED_PREF = "SharedPref";
    private SharedPreferences preferences;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    public static int FOTO_CODE = 1;
    private Button btn_captura;
    private Button btn_salvar;
    private Button btn_tela_produto;
    private ImageView img_foto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ProdutoDAO db = new ProdutoDAO(MainActivity.this);

        btn_captura = this.findViewById(R.id.btn_capturar);
        btn_salvar = this.findViewById(R.id.btn_salvar);
        btn_tela_produto = this.findViewById(R.id.btn_tela_produto);
        img_foto = this.findViewById(R.id.img_foto);

        horarioAcesso();

        btn_tela_produto.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ProdutoActivity.class);
            startActivity(intent);
        });

        btn_captura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(fotoIntent, FOTO_CODE);
            }
        });

        btn_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bitmap bitmap = ((BitmapDrawable) img_foto.getDrawable()).getBitmap();
                File file = new File(MainActivity.this.getExternalFilesDir(null), "img.png");

                try {
                    if(Environment.getExternalStorageState(file).equals(Environment.MEDIA_MOUNTED)) {
                        Log.d("TESTES", file.getAbsolutePath());
                        FileOutputStream out = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
                        out.flush();
                        out.close();
                    }
                } catch(Exception e) {
                    Log.e("TESTES", "Erro na gravação do arquivo:" + e.toString());
                }

                Toast.makeText(MainActivity.this, "Foto salva com sucesso!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        img_foto = findViewById(R.id.img_foto);

        if (requestCode == FOTO_CODE && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            img_foto.setImageBitmap(photo);

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void horarioAcesso() {
        preferences = this.getSharedPreferences(SHARED_PREF,0);
        String time = dateFormat.format(new Date());
        String horario = preferences.getString("time","");

        if (horario.equals("")){
            Toast.makeText(MainActivity.this, "Data atual: " + time, Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(MainActivity.this, "Data do último acesso: " + horario, Toast.LENGTH_LONG).show();
        }

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("time", time);
        editor.apply();
    }
}
