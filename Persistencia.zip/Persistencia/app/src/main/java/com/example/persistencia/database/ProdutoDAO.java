package com.example.persistencia.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.persistencia.model.Produto;

import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO extends SQLiteOpenHelper {

    private static final String DB_NAME = "produto.db";
    private static final int DB_VERSION = 1;
    Cursor cursor;
    SQLiteDatabase db;

    public ProdutoDAO(Context context) {
        super(context, DB_NAME, null, DB_VERSION);

        db = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sqlTabelaProduto = "CREATE TABLE produto (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nomeDoProduto TEXT, " +
                "precoDoProduto REAL)";

        db.execSQL(sqlTabelaProduto);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void inserirProduto(String tabela, ContentValues dados) {

        db.insert(tabela, null, dados);
    }

    /*public List<Produto> listarProdutos() {
        List<Produto> lista = new ArrayList<>();

        //represeta um registro salvo na tabela
        Produto registro;
        String querySQL = "SELECT * FROM produto";
        cursor = db.rawQuery(querySQL, null);

        if (cursor.moveToFirst()) {
            do {
                registro = new Produto();
                registro.setId(cursor.getInt(0));
                registro.setNomeDoProduto(cursor.getString(1));
                registro.setPrecoDoProduto(cursor.getDouble(2));

                lista.add(registro);

            } while (cursor.moveToNext());
        }
        return lista;
    }*/

    public List<Produto> listarProdutos(){
        List<Produto> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        try{
            Cursor cursor = db.query("produto", null, null, null, null, null, null);

            if(cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                    @SuppressLint("Range") String nome = cursor.getString(cursor.getColumnIndex("nomeDoProduto"));
                    @SuppressLint("Range") double preco = cursor.getDouble(cursor.getColumnIndex("precoDoProduto"));


                    Produto produto = new Produto();
                    produto.setId(id);
                    produto.setNomeDoProduto(nome);
                    produto.setPrecoDoProduto(preco);

                    lista.add(produto);

                } while(cursor.moveToNext());
            }
        }catch (Exception e){
            Log.e("ProdutoDAO", e.getMessage());
        }finally {
            db.close();
        }

        return lista;
    }
}
