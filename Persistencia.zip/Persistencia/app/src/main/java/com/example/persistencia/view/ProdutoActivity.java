package com.example.persistencia.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.persistencia.R;
import com.example.persistencia.controller.ProdutoController;
import com.example.persistencia.model.Produto;

import java.util.ArrayList;
import java.util.List;

public class ProdutoActivity extends AppCompatActivity {

    ProdutoController produtoController;
    EditText edit_precoProd;
    EditText edit_nomeProd;
    Button btn_salvarProd;
    Button btn_listarProd;
    TextView tv_listarProd;
    String nomeProduto;
    double precoProduto;
    List<Produto> dados;
    ListView listProd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);

        produtoController = new ProdutoController(ProdutoActivity.this);
        //dados = produtoController.getListaDeDados();

        edit_precoProd = findViewById(R.id.edit_precoProd);
        edit_nomeProd = findViewById(R.id.edit_nomeProd);
        btn_salvarProd = findViewById(R.id.btn_salvarProd);
        btn_listarProd = findViewById(R.id.btn_listarProd);
        tv_listarProd =  findViewById(R.id.listView_listarProd);

        btn_salvarProd.setOnClickListener(view -> {
            Produto produto = new Produto();
            ProdutoController produtoController = new ProdutoController(ProdutoActivity.this);

            precoProduto = Double.parseDouble(edit_precoProd.getText().toString());
            nomeProduto = edit_nomeProd.getText().toString();

            produto.setNomeDoProduto(nomeProduto);
            produto.setPrecoDoProduto(precoProduto);

            produtoController.insert(produto);

            Toast.makeText(this, "Produto salvoo!", Toast.LENGTH_SHORT).show();
        });

        btn_listarProd.setOnClickListener(view -> {
            dados = produtoController.getListaDeDados();

           /* ArrayAdapter adapter = new ArrayAdapter<>(
                    this, android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    dados
            );
            listProd.setAdapter(adapter);*/

            String lista = "";
            for(Produto atual: dados){
                lista += "Nome: "+ atual.getNomeDoProduto() + " Preço: " + atual.getPrecoDoProduto() + "\n";

                tv_listarProd.setText(lista);

            }

        });
    }
}