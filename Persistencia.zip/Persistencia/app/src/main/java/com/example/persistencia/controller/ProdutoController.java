package com.example.persistencia.controller;

import android.content.ContentValues;
import android.content.Context;

import com.example.persistencia.database.ProdutoDAO;
import com.example.persistencia.model.Produto;

import java.util.List;

public class ProdutoController extends ProdutoDAO {

    public ProdutoController(Context context) {
        super(context);
    }

    public void insert(Produto produto) {
        ContentValues dados = new ContentValues();
        dados.put("nomeDoProduto", produto.getNomeDoProduto());
        dados.put("precoDoProduto", produto.getPrecoDoProduto());

        inserirProduto("produto", dados);
    }

    public List<Produto> getListaDeDados() {

        return listarProdutos();
    }

}
